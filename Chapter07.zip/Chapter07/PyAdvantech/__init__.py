import clr
import os
def loadDll(dll_path):
    dll_lib = clr.AddReference(dll_path)  # 加载研华的库，不要加dll后缀
    if dll_lib is None:
        print("程序找不到研华的动态链接库！")
        return None
        exit()
    else:
        print("加载研华动态链接库成功！")
        return dll_lib
# 绝对路径加上dll后缀，相对路径不用加dll
current_path = os.path.dirname(__file__)+'/Automation.BDaq4.dll'
dll_lib = loadDll(current_path)

# 导入所有dll中所有资源，方便其他文件调用
from Automation.BDaq import *

# 判断错误代码是否为错误，是返回True
def BioFailed(errorCode):
    result = (errorCode < ErrorCode.Success) and (errorCode >= ErrorCode.ErrorHandleNotValid)
    return result


