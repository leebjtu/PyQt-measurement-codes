# 硬件设备引入
from Chapter07.PyAdvantech import WaveformAiCtrl, BioFailed, DeviceInformation
from System import Array, Double
# PyQt信息引入
from PyQt6 import QtWidgets
from PyQt6.QtCore import pyqtSlot
from PyQt6.QtWidgets import QWidget
# 其他信息引入
from formBufferedAI_ui import Ui_bufferAI
from threading import Thread
import sys
# 采集卡名称和配置文件路径
deviceDescription = "DemoDevice,BID#0"
profilePath = "../profile/DemoDevice.xml"
class myBufferedAIWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.__ui = Ui_bufferAI()
        self.__ui.setupUi(self)
        self.init()
    # 初始化采集对象信息
    def init(self):
        # 01.创建WaveformAiCtrl对象，选择设备，关联DataReady和Overrun事件
        self.WaveformAiObj = WaveformAiCtrl()
        self.WaveformAiObj.DataReady += self.waveformAiCtrl_dataReady
        self.WaveformAiObj.Overrun += self.waveformAiCtrl_overrun
        self.WaveformAiObj.SelectedDevice = DeviceInformation(deviceDescription)
        # 02.此步骤非必须，查看本采集设备是否支持buffered Ai模式
        bool_ret = self.WaveformAiObj.Features.BufferedAiSupported
        if not bool_ret:
            raise Exception("本卡不支持StreamAI模式！")
        # 03.加载配置文件
        ret = self.WaveformAiObj.LoadProfile(profilePath)
        if BioFailed(ret):
            raise Exception("loadProfile失败了！error_code:%x" % ret)
    # “开始”按键响应函数
    @pyqtSlot()
    def on_btnStart_clicked(self):
        if self.__ui.btnStart.text() == "开始采集":
            self.reCaculatePars()
            self.__ui.widgetMatplot.setChannelCount(self.start_channel, self.channel_count)
            if not self.startGetData():  # 如果准备失败了，就直接返回
                return
            self.__ui.btnStart.setText("停止采集")
            self.__ui.groupBox.setEnabled(False)
        else:
            self.WaveformAiObj.Stop()
            self.WaveformAiObj.Release()  # 释放缓冲区数据
            self.__ui.btnStart.setText("开始采集")
            self.__ui.groupBox.setEnabled(True)
    # 重新根据界面设置配置采集卡参数，不再采用xml配置信息
    def reCaculatePars(self):
        # 获取对象中的一些设置数据，这里神略了数值验证的过程
        self.section_length = eval(self.__ui.textSection.text())
        self.convert_clk_rate = eval(self.__ui.textFrequency.text())  # Hz/Channel
        self.channel_count = eval(self.__ui.cboxChannelCounts.currentText())
        self.start_channel = eval(self.__ui.cboxChannelStart.currentText())
        # 更新配置文件中的设置，不再以配置文件xml作为参考
        self.conversion = self.WaveformAiObj.Conversion
        self.conversion.ChannelCount = self.channel_count
        self.conversion.ChannelStart = self.start_channel
        self.conversion.ClockRate = self.convert_clk_rate  # Hz/Channel
        self.WaveformAiObj.Record.SectionLength = self.section_length
        # 推算一些变量值
        self.frame_time = self.section_length / self.convert_clk_rate  # 每次触发时间间隔
        self.convert_period = 1.0 / self.convert_clk_rate  # 采样周期：每个点采样间隔
        self.section_buffer = Array[Double](range(0, self.section_length * self.channel_count))  # 取出来的原始数据
        self.time_buffer = [i * self.convert_period for i in range(self.section_length)]  # 绘图时间缓冲区
    # 准备采集数据
    def startGetData(self):
        try:
            # 04.Prepare()准备
            ret = self.WaveformAiObj.Prepare()
            if BioFailed(ret):
                raise IOError("Prepare失败了！error_code:%x" % ret)
            # 05.开始采集，填充缓冲区
            errorCode = self.WaveformAiObj.Start()
            if BioFailed(errorCode):
                raise IOError("Start！error_code:%x" % ret)
        except IOError as e:
            print("采集卡准备异常！")
            return False
        else:
            return True
    # DataReady事件响应函数
    def waveformAiCtrl_dataReady(self, sender, bfdAiEventArgs):
        WaveformAiObj = sender
        self.time_buffer = [(data + self.frame_time) for data in self.time_buffer]
        WaveformAiObj.GetData(self.section_length * self.channel_count, self.section_buffer)
        list_section_buffer = list(self.section_buffer)
        # 采用多线程绘图
        t = Thread(target=self.__ui.widgetMatplot.plot, args=(self.time_buffer, list_section_buffer))
        t.setDaemon(True)
        t.start()
    # OverRun事件响应函数
    def waveformAiCtrl_overrun(self, sender, bfdAiEventArgs):
        print("Streaming AI is Over run !")
        print("缓冲区没来得及取的数据个数为：%d" % bfdAiEventArgs.Count)
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    bufferAI = myBufferedAIWidget()
    bufferAI.show()
    sys.exit(app.exec())


