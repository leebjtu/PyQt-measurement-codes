# myMatplot.py
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT as NavigationToolbar
from matplotlib import pyplot as plt
class QmyMatplot(FigureCanvas):
    def __init__(self, parent =None):
        # 下面是为了正常显示中文标签
        plt.rcParams["font.family"] = ["SimHei"]
        plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号
        plt.rcParams["font.size"] = 9 # 字号
        self.fig = plt.figure()
        FigureCanvas.__init__(self, self.fig)
        self.toolbar = NavigationToolbar(self, self, coordinates=False)
        # 增加图框
        self.ax = self.fig.add_axes([0.15, 0.15, 0.75, 0.7])  # 在left, bottom, width, height = 0.1, 0.1, 0.8, 0.8
        self.initFigure()
    # 设置通道数，channel_count决定生成多少条line
    def setChannelCount(self, start_channel, channel_count):
        self.channel_count = channel_count
        # 清除以前的曲线图
        while len(self.ax.lines) > 0:  self.ax.lines[0].remove()
        # 重新增加channel_count条line, 数量与通道相匹配
        line_colors = ['red', 'green', 'blue', 'black', 'orange', 'purple', 'brown', 'pink']
        line_styles = ['-', '--', '-.', ':']
        for i in range(0, self.channel_count): # 每plot一次，self.ax.lines就自动添加一条line，返回为line2D对象
            self.ax.plot([], [],
                         label='channel%d' % (start_channel +i),
                         linewidth=1,
                         color=line_colors[i % len(line_colors)],
                         linestyle=line_styles[i % len(line_styles)])
        self.ax.legend().set_draggable(True)
        self.ax.set_autoscalex_on(True)  # x轴自动范围打开，y轴不打开
    # 设置ax标签信息
    def initFigure(self):
        # https://matplotlib.org/stable/api/axes_api.html
        self.ax.set_title('Data in channels')
        self.ax.set_xlabel('Time/s')
        self.ax.set_ylabel('Voltage/V')
        self.ax.set_ylim(-10, 10)
        self.ax.grid(axis='both')
    # 绘制数据
    def plot(self, dataX, dataY):
        lines = self.ax.get_lines()
        for index in range(len(lines)):
            lines[index].set_data(dataX, dataY[index::self.channel_count])
        self.ax.relim()
        self.ax.autoscale_view(scalex=True)
        self.fig.canvas.draw()
        self.fig.canvas.flush_events()
