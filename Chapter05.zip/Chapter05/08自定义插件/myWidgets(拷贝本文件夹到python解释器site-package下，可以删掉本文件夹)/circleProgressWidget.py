"""
文件名称：cirlceProgressWidget.py
文件内容：环形进度条控件的实现
"""
from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import pyqtProperty

class myQcircleProgressWidget(QWidget):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.painter = QPainter()
		#定义一些局部变量,并依附于属性
		self._maxValue = 100  # 最大值
		self._minValue = 0  # 最小值
		self._value = 70 # 目标值
		self._precision  = 0 # 精确度,小数点后几位
		self._showPercent  = False # 显示百分比
		self._alarmMode  = 1  # 警戒报警模式,进度为不同的颜色
		self._startAngle = 0  # 起始角度
		self._ringPadding  = 5   # 圆环间距
		self._ringWidth = 30   # 圆环宽度
		self._clockWise = False # 是否顺时针

		self._bgColor = Qt.GlobalColor.white  #  背景颜色
		self._textColor  = Qt.GlobalColor.black  #  文字颜色
		self._ringColor  = QColor(77,206,247,255)#  圆环颜色
		self._ringBgColor = QColor(77,206,247,25)  #  圆环进度背景
		self._circleColor  = QColor(229,229,227,250)   #  中心圆颜色
		# 警戒阈值，默认值是量程的0.9作为警戒
		self._alarmValue  = (self.maxValue - self.minValue) * 0.9 + self.minValue
		self._alarmColor  = Qt.GlobalColor.red  #  警戒环形颜色

	# 最大值
	@pyqtProperty(float)
	def maxValue(self):
		return self._maxValue

	@maxValue.setter
	def maxValue(self, value):
		self._maxValue = value
		self.update()

	# 最小值
	@pyqtProperty(float)
	def minValue(self):
		return self._minValue

	@minValue.setter
	def minValue(self, value):
		self._minValue = value
		self.update()

	# 目标值
	@pyqtProperty(float)
	def value(self):
		return self._value

	@value.setter
	def value(self, value):
		self._value = value
		self.update()

	# 精确度,小数点后几位
	@pyqtProperty(int)
	def precision(self):
		return self._precision

	@precision.setter
	def precision(self, value):
		self._precision = value
		self.update()

	# 是否显示百分比
	@pyqtProperty(bool)
	def showPercent(self):
		return self._showPercent

	@showPercent.setter
	def showPercent(self, value):
		self._showPercent = value
		self.update()

	# 警戒报警模式
	@pyqtProperty(int)
	def alarmMode(self):
		return self._alarmMode

	@alarmMode.setter
	def alarmMode(self, value):
		self._alarmMode = value
		self.update()

	# 起始角度
	@pyqtProperty(int)
	def startAngle(self):
		return self._startAngle

	@startAngle.setter
	def startAngle(self, value):
		self._startAngle = value
		self.update()

	# 圆环间距
	@pyqtProperty(int)
	def ringPadding(self):
		return self._ringPadding

	@ringPadding.setter
	def ringPadding(self, value):
		self._ringPadding = value
		self.update()

	# 圆环宽度
	@pyqtProperty(int)
	def ringWidth(self):
		return self._ringWidth

	@ringWidth.setter
	def ringWidth(self, value):
		self._ringWidth = value
		self.update()


	# 背景颜色
	@pyqtProperty(QColor)
	def bgColor(self):
		return self._bgColor


	@bgColor.setter
	def bgColor(self, value):
		self._bgColor = value
		self.update()


	# 文字颜色
	@pyqtProperty(QColor)
	def textColor(self):
		return self._textColor


	@textColor.setter
	def textColor(self, value):
		self._textColor = value
		self.update()


	# 圆环颜色
	@pyqtProperty(QColor)
	def ringColor(self):
		return self._ringColor


	@ringColor.setter
	def ringColor(self, value):
		self._ringColor = value
		self.update()


	# 圆环进度背景
	@pyqtProperty(QColor)
	def ringBgColor(self):
		return self._ringBgColor


	@ringBgColor.setter
	def ringBgColors(self, value):
		self._ringBgColor = value
		self.update()


	#  中心圆颜色
	@pyqtProperty(QColor)
	def circleColor(self):
		return self._circleColor


	@circleColor.setter
	def circleColor(self, value):
		self._circleColor = value
		self.update()


	# 警戒阈值
	@pyqtProperty(int)
	def alarmValue(self):
		return self._alarmValue


	@alarmValue.setter
	def alarmValue(self, value):
		self._alarmValue = value
		self.update()


	#  警戒环形颜色
	@pyqtProperty(QColor)
	def alarmColor(self):
		return self._alarmColor


	@alarmColor.setter
	def alarmColor(self, value):
		self._alarmColor = value
		self.update()


	# 是否顺时针
	@pyqtProperty(bool)
	def clockWise(self):
		return self._clockWise


	@clockWise.setter
	def clockWise(self, value):
		self._clockWise = value
		self.update()

	def sizeHint(self):
		return QSize(200, 200)

	def paintEvent(self, event):
		# 开始绘图
		self.painter.begin(self)
		# 开启防锯齿渲染
		self.painter.setRenderHint(QPainter.RenderHint.Antialiasing)
		# 平移坐标轴中心,等比例缩放
		side = min(self.width(), self.height())
		self.painter.translate(self.width() / 2, self.height() / 2)
		self.painter.scale(side / 200.0, side / 200.0)

		# 绘制背景
		self.drawBkg()
		# 绘制环形背景
		self.drawRing()
		# 绘制间隔, 重新绘制一个圆遮住, 产生间距效果
		if (self.ringPadding > 0):
			self.drawPadding()
		# 绘制中间圆
		self.drawCircle()
		# 绘制当前值
		self.drawValue()
		# self.painter.drawEllipse(0,0,self.width(),self.height())
		# 结束绘图
		self.painter.end()

	def drawBkg(self):
		self.painter.save()
		self.painter.setPen(Qt.PenStyle.NoPen)
		# 背景半径为100，设置成控件控件尺寸的一半，这样控件全部能撑满整个空间
		radius = 100
		# 这里有个技巧, 如果没有间距则设置成圆环的背景色
		self.painter.setBrush(self.ringBgColor if self.ringPadding ==0 else self.bgColor)
		# 画背景圆
		self.painter.drawEllipse(-radius, -radius, radius * 2, radius * 2)
		self.painter.restore()

	# 控件bar背景色
	def drawRing(self):
		self.painter.save()
		self.painter.setPen(Qt.PenStyle.NoPen)
		self.painter.setBrush(self.ringColor)
		# 饼图的半径
		radius = 100 - self.ringPadding
		rect = QRectF(-radius, -radius, radius * 2, radius * 2)
		# 计算总范围角度, 当前值范围角度, 剩余值范围角度
		angleAll = 360.0
		angleCurrent = angleAll * ((self.value - self.minValue) / (self.maxValue - self.minValue))
		angleOther = angleAll - angleCurrent
		# 如果逆时针
		if self.clockWise == False:
			angleCurrent = -angleCurrent
			angleOther = -angleOther
		# 动态设置当前进度颜色
		color = QColor(self.ringColor)
		if (self.alarmMode == 1):
			if self.value >= self.alarmValue:
				color = self.alarmColor
		elif self.alarmMode == 2:
			if self.value <= self.alarmValue:
				color = self.alarmColor
		# 绘制当前值饼圆
		self.painter.setBrush(color)
		self.painter.drawPie(rect, int(self.startAngle - angleCurrent) * 16, int(angleCurrent * 16))
		# 绘制剩余值饼圆
		self.painter.setBrush(self.ringBgColor)
		self.painter.drawPie(rect, int(self.startAngle - angleCurrent - angleOther) * 16, int(angleCurrent * 16))
		self.painter.restore()

	# 当	self.ringPadding>0时，才调用下面函数
	def drawPadding(self):
		self.painter.save()
		radius = 100 - self.ringWidth - self.ringPadding
		self.painter.setPen(Qt.PenStyle.NoPen)
		self.painter.setBrush(self.bgColor)
		self.painter.drawEllipse(-radius, -radius, radius * 2, radius * 2)
		self.painter.restore()

	def drawCircle(self):
		self.painter.save()
		# 计算圆半径
		radius = 100 - self.ringWidth - (self.ringPadding * 2)
		self.painter.setPen(Qt.PenStyle.NoPen)
		self.painter.setBrush(self.circleColor)
		self.painter.drawEllipse(-radius, -radius, radius * 2, radius * 2)
		self.painter.restore()
	# 绘制文字
	def drawValue(self):
		self.painter.save()
		# 计算圆半径
		radius = 99 - self.ringWidth - (self.ringPadding * 2)
		self.painter.setPen(self.textColor)
		# 计算字体的大小
		font = QFont()
		fontSize = radius - ( 20 if self.showPercent else 6)
		font.setPixelSize(fontSize)
		self.painter.setFont(font)
		# 文本矩形框的位置
		textRect = QRectF(-radius, -radius, radius * 2, radius * 2)
		if (self.showPercent):
			percent = (self.value * 100) / (self.maxValue - self.minValue)
			strValue = ("{:."+str(self.precision)+"f}").format(percent)+"%"
		else:
			strValue =("{:."+str(self.precision)+"f}").format(self.value)
		self.painter.drawText(textRect, Qt.AlignmentFlag.AlignCenter, strValue)
		self.painter.restore()

if __name__ == "__main__":
    import sys
    from PyQt6 import QtWidgets
    app = QtWidgets.QApplication(sys.argv)
    ui = myQcircleProgressWidget()
    ui.setWindowTitle("自定义插件示例")
    ui.show()
    sys.exit(app.exec())