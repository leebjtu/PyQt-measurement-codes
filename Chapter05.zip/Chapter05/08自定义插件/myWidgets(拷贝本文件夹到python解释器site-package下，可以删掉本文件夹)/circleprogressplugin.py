from PyQt6.QtDesigner import QPyDesignerCustomWidgetPlugin
# 导入与插件图标相关的类
from PyQt6.QtGui import QIcon, QPixmap
# 从库中导入自定义控件类ledWidget
from myWidgets.circleProgressWidget import myQcircleProgressWidget
# 插件类名称可以随便命名，但是必须继承自QPyDesignerCustomWidgetPlugin类
class circleProgressPlugin(QPyDesignerCustomWidgetPlugin):
# \_\_init\_\_()函数只用来建立插件和定义插件内部的一些变量
	def __init__(self, parent=None):
		# QPyDesignerCustomWidgetPlugin.__init__(self)
		super().__init__(parent)
		self.initialized = False
# initialize()和isInitialized()函数是为了插件函数只初始化一次
# 在initialize()中可以设置任何需要的资源
	def initialize(self, core):
		if self.initialized:
			return
		self.initialized = True

	def isInitialized(self):
		return self.initialized
# 内置接口函数的实现，创建并返回自定义类的一个实例
	def createWidget(self, parent):
		return myQcircleProgressWidget(parent)
# 内置接口函数的实现，给插件取一个名字
	def name(self):
		return "myQcircleProgressWidget"
# 内置接口函数的实现，给插件分组，返回组名
	def group(self):
		return "myPlugins"
# 内置接口函数的实现，给插件添加图标，返回QIcon图标
	def icon(self):
		_logo_pixmap = QPixmap(_logo_32x32_xpm)
		return QIcon(_logo_pixmap)
# 内置接口函数的实现，给插件添加toolTip字符串
	def toolTip(self):
		return "my circleProgressWidget"
# 内置接口函数的实现，给插件添加"What's This?"字符串描述符
	def whatsThis(self):
		return "This is my circleProgressWidget" # 2025.10.14改
# 内置接口函数的实现，返回该插件是否为容器类
	def isContainer(self):
		return False

# 内置接口函数的实现，以XML形式，返回该插件属性的一些默认值
	def domXml(self):
		return (
		'<widget class="myQcircleProgressWidget" name=\"circleProgressWidget\">\n'
		" <property name=\"toolTip\" >\n"
		"  <string>The circleProgressWidget</string>\n"
		" </property>\n"
		" <property name=\"whatsThis\" >\n"
		"  <string>circleProgressWidget "
		"circleProgressWidget.</string>\n"
		" </property>\n"
		"</widget>\n"
		)
# 内置接口函数的实现，返回包含自定义控件的模块
# myWidgets 为本插件类文件存放的文件夹名称
	def includeFile(self):
		return "myWidgets.circleProgressWidget"

# xpm图标的编码文件.由于体积庞大，这里只显示部分
_logo_32x32_xpm = [
    "16 16 3 1 ",
    "  c black",
    ". c #0000E3",
    "X c None",
    "XXXXXXXXXXXXXXXX",
    "XXXXXXXXXXXXXXXX",
    "XXXXXXXXXXXXXXXX",
    " XX X  XX  XX  X",
    " XX    XX  XX XX",
    " XX  X X   XXX  ",
    " XX XX X XX X  X",
    "XXXXXXXXXXXXXXXX",
    "................",
    "XXXXXXXXXXXXXXXX",
    "XXX XX X X   XXX",
    "XXX X XX XX XXXX",
    "XXXX  XX X XXXXX",
    "XXXX  XX X   XXX",
    "XXXXXXXXXXXXXXXX",
    "XXXXXXXXXXXXXXXX"]

# #QPyDesignerCustomWidgetCollection.registerCustomWidget(myQcircleProgressWidget, module="myQcircleProgressWidget",
#                                                        tool_tip="my circleProgressWidget toolTip", xml=domXml())