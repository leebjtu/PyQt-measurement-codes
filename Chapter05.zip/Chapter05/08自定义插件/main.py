from myWidgets.circleProgressWidget import myQcircleProgressWidget
if __name__ == "__main__":
    import sys
    from PyQt6 import QtWidgets
    app = QtWidgets.QApplication(sys.argv)
    ui = myQcircleProgressWidget()
    ui.setWindowTitle("自定义插件示例")
    ui.show()
    sys.exit(app.exec())