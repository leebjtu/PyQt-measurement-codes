'''
功能：自动调用虚拟环境中的qt designer，该插件回自动加载自定义插件
该文件在当前虚拟环境中，自动添加PYQTDESIGNERPATH
环境变量的值，并在当前虚拟环境下运行Qt designer。只有在当前环境下，Qt designer会自动在PYQTDESIGNERPATH路径下寻找插件，然后加载。
'''
# 在文件顶部添加防止重复执行的保护
if __name__ == "__main__":
    '''
    该文件在当前虚拟环境职工，自动添加PYQTDESIGNERPATH
    环境变量的值，并在当前虚拟环境下运行Qt designer。只有在当前环境下，Qt designer会自动在PYQTDESIGNERPATH路径下寻找插件，然后加载。
    '''
    import os
    import sys
    import subprocess

    # 注意路径不能有中文！！否则会加载插件失效
    os.environ['PYQTDESIGNERPATH'] = os.environ.get('VIRTUAL_ENV') + r'\Lib\site-packages\myWidgets'
    os.environ['PYQTDESIGNERPATH'] = r'E:\temp\myWidgets'

    # 检查运行环境
    def check_running_environment():
        if os.environ.get('VIRTUAL_ENV'):
            return f"虚拟环境: {os.environ.get('VIRTUAL_ENV')}"
        elif hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
            return "虚拟环境中(通过sys检测)"
        else:
            return "全局Python环境"

    current_path = os.environ.get('PYQTDESIGNERPATH')
    print(f"当前 PYQTDESIGNERPATH: {current_path}")
    print(f"运行环境: {check_running_environment()}")

    if current_path:
        print("该变量在当前会话中被设置")
    else:
        print("该变量已清除")

    # 调用 Qt Designer
    def launch_qt_designer():
        try:
            # 获取虚拟环境路径
            virtual_env = os.environ.get('VIRTUAL_ENV')
            if virtual_env:
                # 在虚拟环境中使用 pyqt6-tools designer
                print("在虚拟环境中调用 Qt Designer...")
                subprocess.run(['pyqt6-tools', 'designer'], check=True)
        except subprocess.CalledProcessError as e:
            print(f"无法启动 Qt Designer: {e}")
        except FileNotFoundError:
            print("找不到 Qt Designer，请确保已正确安装 PyQt6 和 pyqt6-tools")

    # 调用 Qt Designer
    print("\n正在启动 Qt Designer...")
    launch_qt_designer()
