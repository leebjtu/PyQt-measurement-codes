#!/usr/bin/env python3
# coding=utf-8
"""
Author: 三石
Time: 2022-01-04, 20:43
File: myTank.py
Function: 定义自定义控件类QmyTank
"""
import sys
from PyQt6.QtWidgets import QApplication,QWidget
from PyQt6.QtCore import pyqtSignal,Qt,QRect,QPointF
from PyQt6.QtGui import QPainter,QPen,QBrush,QFont,QColor
from PyQt6.QtCore import Qt
class QmyTank(QWidget):
    liquidLevelChanged=pyqtSignal(float) # 液位变化时发射的信号
    def __init__(self,parent=None):
        super().__init__(parent)
        self.__value = 120
        self.__minValue = 0
        self.__maxValue = 200
        self.__percent = 0
        self.__tankPenWidth = 5 # 水箱壁面的像素粗细
        self.__padding =1  # 水和水箱壁面的像素间距
        self.__unit = "cm"
# =================value属性：液位高度=====================
    @property
    def value(self):
        return self.__value
    @value.setter
    def value(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if (value >= self.__minValue) and (value <= self.__maxValue):
                if (self.__value != value): # 和上一次不一樣的時候才更新，減小更新負擔
                    self.__value = value
                    self.liquidLevelChanged.emit(value)
                    self.repaint()

# =================minValue属性：液位最小高度=====================
    @property
    def minValue(self):
        return self.__minValue
    @minValue.setter
    def minValue(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if value< self.value: # 设置的最小值只能小于当前值，否则无效
                self.__minValue = value
                self.repaint()

    # =================maxValue属性：液位最大高度=====================
    @property
    def maxValue(self):
        return self.__maxValue
    @maxValue.setter
    def maxValue(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if value > self.value:  # 设置的最小值只能小于当前值，否则无效
                self.__maxValue = value
                self.repaint()


# =================重绘事件处理函数=====================
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setWindow(-self.width()/2.0,-self.height()/2.0,self.width(), self.height()) # 设置成窗口坐标系，坐标原点在几何中心
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        self.drawTank(painter) # 绘制界面

# =================绘制界面函数=====================
    def drawTank(self,painter):
        pen = QPen()
        pen.setWidth(self.__tankPenWidth)
        pen.setColor(Qt.GlobalColor.black)
        painter.setPen(pen)
        W = self.width()
        H = self.height()
        # 1.绘制水箱轮廓
        painter.drawLine(-W/2, -H/ 2, -W/2, H/2)
        painter.drawLine(-W/2, H/2, W/2, H/2)
        painter.drawLine(W/2, H/2, W/2, -H/2)
        # 2.绘制水箱液面
        brush = QBrush()
        brush.setColor(QColor("#74cfff"))
        brush.setStyle(Qt.BrushStyle.SolidPattern)
        painter.setBrush(brush)
        painter.setPen(Qt.PenStyle.NoPen)
        self.__percent = (self.__value - self.__minValue) / (self.__maxValue - self.__minValue)  # 0-1取值 百分数
        self._deepth = self.__percent * H * 0.85  #  像素单位的深度，0.85是限制显示的最高液位不得超过水槽高度的0.85
        y_deep = H / 2 - self._deepth    # 液面的中值坐标
        painter.drawRect(QRect(-W*0.5+(self.__tankPenWidth+self.__padding),y_deep-(self.__tankPenWidth+self.__padding),W-(self.__tankPenWidth+self.__padding)*2,self._deepth))
        # 3.绘制水箱中的文字
        penText = QPen(Qt.GlobalColor.black)
        penText.setWidth(1)
        painter.setPen(penText)
        painter.setFont(QFont("微软雅黑", H / 15, QFont.Weight.Medium))  # 第二个参数是字体大小
        painter.setOpacity(0.4)  # 0：完全透明，1：完全不透明
        painter.drawText(QPointF(-W/4, y_deep-15), "%.1f%s(%.0f%%)"%(self.__value,self.__unit,self.__percent*100))  # 绘制文字

# =================窗口测试程序=====================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    form = QmyTank()
    form.show()
    sys.exit(app.exec())
