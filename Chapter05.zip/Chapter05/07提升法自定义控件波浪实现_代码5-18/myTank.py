#!/usr/bin/env python3
# coding=utf-8
"""
Author: 三石
Time: 2022-01-04
File: myTank.py
Function: 定义自定义控件类QmyTank,加上水波浪效果
"""
import sys
import math
from PyQt6.QtWidgets import QApplication,QWidget
from PyQt6.QtCore import pyqtSignal,Qt,QRect,QPointF,QTimer
from PyQt6.QtGui import QPainter,QPen,QBrush,QFont,QColor,QPainterPath

class QmyTank(QWidget):
    liquidLevelChanged=pyqtSignal(float) # 液位变化时发射的信号
    def __init__(self,parent=None):
        super().__init__(parent)
        self.__value = 120
        self.__minValue = 0
        self.__maxValue = 200
        self.__percent = 0
        self.__tankPenWidth = 5 # 水箱壁面的像素粗细
        self.__padding =1  # 水和水箱壁面的像素间距
        self.__unit = "cm"
        # 波浪相关的变量
        self.__numberOfWaves = 1.2  # 页面要显示的波浪的周期个数
        self.__frequency = 0  # 波浪的频率,Hz,值越大，波浪越紧凑
        self.__amplitude = 0  # 像素，波浪幅值
        self.__phase1 = 0  # 像素，波浪1相位
        self.__phase2 = 0  # 像素，波浪2相位
        self.__deepth = 0  # 水位高度
        # 定义一个Timer，刷新波浪用
        self.__timer = QTimer()
        self.__t = 0  # 时间
        self.__sampleTime = 0.1  # 定时器触发时间，单位s
        self.__timer.setInterval(self.__sampleTime * 1000)  # 单位：ms
        self.__timer.timeout.connect(self.time_out)
        self.__timer.start()

# =================value属性：液位高度=====================
    @property
    def value(self):
        return self.__value
    @value.setter
    def value(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if (value >= self.__minValue) and (value <= self.__maxValue):
                if (self.__value != value): # 和上一次不一樣的時候才更新，減小更新負擔
                    self.__value = value
                    self.liquidLevelChanged.emit(value)
                    self.repaint()

# =================minValue属性：液位最小高度=====================
    @property
    def minValue(self):
        return self.__minValue
    @minValue.setter
    def minValue(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if value< self.value: # 设置的最小值只能小于当前值，否则无效
                self.__minValue = value
                self.repaint()

    # =================maxValue属性：液位最大高度=====================
    @property
    def maxValue(self):
        return self.__maxValue
    @maxValue.setter
    def maxValue(self, value):
        if isinstance(value, int) or isinstance(value, float):
            if value > self.value:  # 设置的最小值只能小于当前值，否则无效
                self.__maxValue = value
                self.repaint()

# =================重绘事件处理函数=====================
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setWindow(-self.width()/2.0,-self.height()/2.0,self.width(), self.height()) # 设置成窗口坐标系，坐标原点在几何中心
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        self.drawTank(painter) # 绘制界面

# =================绘制界面函数=====================
    def drawTank(self,painter):
        pen = QPen()
        pen.setWidth(self.__tankPenWidth)
        pen.setColor(Qt.GlobalColor.black)
        painter.setPen(pen)
        W = self.width()
        H = self.height()
        # =================1.绘制水箱轮廓=====================
        painter.drawLine(-W/2, -H/ 2, -W/2, H/2)
        painter.drawLine(-W/2, H/2, W/2, H/2)
        painter.drawLine(W/2, H/2, W/2, -H/2)
        # =================2.绘制水箱液面=====================
        brush = QBrush()
        brush.setColor(QColor("#74cfff"))
        brush.setStyle(Qt.BrushStyle.SolidPattern)
        painter.setBrush(brush)
        painter.setPen(Qt.PenStyle.NoPen)
        self.__percent = (self.__value - self.__minValue) / (self.__maxValue - self.__minValue)  # 0-1取值 百分数
        self.__deepth = self.__percent * H * 0.85  #  像素单位的深度，0.85是限制显示的最高液位不得超过水槽高度的0.85
        y_deep = H / 2 - self.__deepth    # 液面的中值坐标
        paddings = self.__tankPenWidth+self.__padding #计算左、右和下间隔
        #开始填充波浪
        leftTopCornerX = -W // 2 + paddings # 计算页面矩形的一些点的坐标
        rightTopCornerX = W // 2 - paddings
        leftBottomCornerY = H/2 - paddings
        self.__frequency = self.__numberOfWaves / W  # 计算正弦频率，该值取决于要显示的正弦波个数
        self.__amplitude = H / 40 # 计算正弦幅值
        self.__phase1 = W / 400 * self.__t  # 每次更新相位自动加
        # 分母5表示两个波滞后1/5个周期
        self.__phase2 = self.__phase1 + 2 * math.pi * self.__frequency * W / 5
        # 创建2个QPainterPath，用来绘制水轮廓
        waterPath1 = QPainterPath()
        waterPath2 = QPainterPath()
        # QPainterPath波浪起点
        waterPath1.moveTo(leftTopCornerX, y_deep)
        waterPath2.moveTo(leftTopCornerX, y_deep)
        stepDraw = W // 50 # X方向的绘制步长，决定分段曲线绘制细腻程度
        # QPainterPath波浪曲线绘制
        for x_wave in range(leftTopCornerX, rightTopCornerX, stepDraw):
            y_wave1 = self.__amplitude * math.sin(2 * math.pi * self.__frequency * x_wave + self.__phase1) + y_deep  # 计算波浪点y坐标
            y_wave2 = self.__amplitude * math.sin(2 * math.pi * self.__frequency * x_wave + self.__phase2) + y_deep  # 计算波浪点y坐标
            # 画微分线段
            waterPath1.lineTo(x_wave, y_wave1)
            waterPath2.lineTo(x_wave, y_wave2)
        # QPainterPath波浪最后一段曲线直至右边界
        waterPath1.lineTo(rightTopCornerX, self.__amplitude * math.sin(2 * math.pi * self.__frequency * rightTopCornerX + self.__phase1) + y_deep)  # 移动到右下角结束点,整体形成一个闭合路径
        waterPath2.lineTo(rightTopCornerX, self.__amplitude * math.sin(2 * math.pi * self.__frequency * rightTopCornerX + self.__phase2) + y_deep)  # 移动到右下角结束点,整体形成一个闭合路径
        # QPainterPath绘制到右下角
        waterPath1.lineTo(rightTopCornerX, leftBottomCornerY)
        waterPath2.lineTo(rightTopCornerX, leftBottomCornerY )
        # QPainterPath绘制到左下角
        waterPath1.lineTo(leftTopCornerX, leftBottomCornerY)
        waterPath2.lineTo(leftTopCornerX, leftBottomCornerY)
        # QPainterPath绘制到起点，闭合
        waterPath1.lineTo(leftTopCornerX, y_deep)
        waterPath2.lineTo(leftTopCornerX, y_deep)
        # 前波浪填充
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#008B8B"))
        painter.drawPath(waterPath1)
        # 后波浪填充
        painter.setBrush(QColor("#40E0D0"))
        painter.setOpacity(0.5)
        painter.drawPath(waterPath2)
        # =================3.绘制水箱中的文字=====================

        penText = QPen(Qt.GlobalColor.black)
        penText.setWidth(1)
        painter.setPen(penText)
        painter.setFont(QFont("微软雅黑", H / 15, QFont.Weight.Medium))  # 第二个参数是字体大小
        painter.setOpacity(0.4)  # 0：完全透明，1：完全不透明
        painter.drawText(QPointF(-W/4, y_deep-15), "%.1f%s(%.0f%%)"%(self.__value,self.__unit,self.__percent*100))  # 绘制文字

    def time_out(self):
        self.__t += self.__sampleTime
        self.update() # 重绘界面，事件队列形式调用paintEvent()，以优化速度和减少闪烁
# =================窗口测试程序=====================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    form = QmyTank()
    form.show()
    sys.exit(app.exec())
