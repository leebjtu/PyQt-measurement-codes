import serial
import struct
from threading import Thread
from queue import Queue
# 将字节流data_array按照指定的格式字符串format_str解包成变量元组result
def deFrame(format_str, data_array):
    s = struct.Struct(format_str)  # 按格式字符串的生成结构体变量
    result = s.unpack_from(data_array, 0)
    return result
# 计算data_array的和校验是否与check_code一致
def checksum(data_array, check_code):
    result = True if check_code == (sum(data_array) & 0xFF) else False
    return result
# 线程1：获取串口数据，seri:串口对象，message:要填入消息的Queue队列
def getData(ser, message):
    print("waiting for the data from the serial port...")
    while True:
        data_bytes = ser.read_until(expected=b'\x55\xaa') + ser.read_all()
        message.put(data_bytes)  # 填入消息
# 线程2：获取串口数据后的处理数据，message：要消化消息的Queue队列
def processData(message):
    while True:
        data_bytes = message.get()  # 阻塞，等消息来
        while len(data_bytes) != 0:  # 循环：考虑多帧粘连一起形成长字节流
            length = data_bytes[3]  # 提取出当前帧后面数据长度
            frame_length = length + 4  # 计算当前帧长度
            data_bytes_frame = data_bytes[0:frame_length]  # 获取当前帧数据
            print(data_bytes_frame.hex('-')) # 打印出当前帧
            data_bytes = data_bytes[frame_length:] # 获取下一帧数据
            if data_bytes_frame[0:2] == b'\x55\xaa':  # 防止窜帧
                if checksum(data_bytes_frame[:-1], data_bytes_frame[-1]):  # 校验和是否正确
                    if data_bytes_frame[2] == 0x01:  # 0x01操作码
                            ser.write(b'\x55\xaa\x05\x00\x04')  # 反馈
                            vars = deFrame('<2s2B2fi2B', data_bytes_frame)  # 解包字节流数据
                            print("温度值：%.2f， 湿度值：%.2f，人头数：%d，蹲位情况：%s" %
                                  (vars[2], vars[3], vars[4], bin(vars[5])))
                    elif data_bytes_frame[2] == 0x02:  # 0x02操作码，后面根据业务续写
                        pass # 这里可以不添加自己的帧协议解析内容
                    else:  # 未定义的操作码
                        print("未知操作码！")
                        ser.write(b'\x55\xaa\x05\x03\x07') # 反馈
                else:
                    print("校验码错误！")
                    ser.write(b'\x55\xaa\x05\x02\x06') # 反馈
# 主程序
if __name__ == '__main__':
    ser = serial.Serial("com3", 9600)
    message = Queue()
    t_getdata = Thread(target=getData, args=(ser, message))
    t_processdata = Thread(target=processData, args=(message,))
    t_getdata.setDaemon(True)
    t_processdata.setDaemon(True)
    t_getdata.start()
    t_processdata.start()
    input("press any key to continue...")
    ser.close()
