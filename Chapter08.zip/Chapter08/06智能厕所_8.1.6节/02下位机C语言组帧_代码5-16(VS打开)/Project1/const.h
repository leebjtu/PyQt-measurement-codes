#ifndef CONST_H 
#define CONST_H 
/*************************************************************************************/
//  �������Ͷ���
/*************************************************************************************/
typedef unsigned char  bool;
typedef unsigned char  uint8_t;                          
typedef signed   char  int8_t;                      
typedef unsigned short uint16_t;                       
typedef signed   short int16_t;                     
typedef unsigned int   uint32_t;                     
typedef signed   int   int32_t;    
typedef unsigned long long int64_t;                       
typedef long long      uint64_t;                         
typedef float          float32;                
typedef double         float64;

#endif
