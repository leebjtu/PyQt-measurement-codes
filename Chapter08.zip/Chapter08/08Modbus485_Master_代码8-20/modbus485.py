import serial
import struct
import modbus_tk.defines as cst
import modbus_tk.modbus_rtu as modbus_rtu

# 线圈地址和寄存器地址是两套逻辑地址，地址可以重叠：
# 1个线圈地址就是1位，1个寄存器地址占2个字节
if __name__ == '__main__':
    ser = serial.Serial('COM2', baudrate=9600, bytesize=8, parity='N', stopbits=1)
    master = modbus_rtu.RtuMaster(ser)  # 基于com2上跑modbus RTU协议
    master.set_timeout(3)
    master.open()
    # f:float,4个字节，I:unsiged int,4个字节，H:unsiged short,2个字节
    registers_data_format = '>ffLH'  # 连续读取的变量格式
    registers_start_addr = 10  # 寄存器读起始地址
    slave_ID = 1  # 被读设备的ID
    # 01读保持寄存器
    registers_data = master.execute(slave_ID, # 读设备ID
                                    # 寄存器读操作
                                    cst.READ_HOLDING_REGISTERS,
                                    # 寄存器读起始地址
                                    registers_start_addr,
                                    # 寄存器读的地址数，不是字节数！
                                    struct.calcsize(registers_data_format) // 2,
                                    # 格式字符串
                                    data_format=registers_data_format)
    print("读寄存器的值："+str(registers_data))
    # 02写保持寄存器，下面除以2表示1个地址位存放2个字节
    datas_write = [12.1, 14.5, 100, 22]
    rtu_data = master.execute(slave_ID,
                              cst.WRITE_MULTIPLE_REGISTERS,
                              registers_start_addr,
                              struct.calcsize(registers_data_format) // 2,
                              output_value=datas_write,
                              data_format=registers_data_format)
    print(rtu_data)
    # 03读线圈
    coils_start_addr = 10  # 线圈读起始地址
    coils_num = 4  # 读取的线圈的个数
    coils_data = master.execute(slave_ID,
                                cst.READ_COILS,
                                coils_start_addr,
                                coils_num)
    print("读线圈的值："+str(coils_data))
    # 04写线圈
    coils_write = [0, 1, 1, 0]  # 写入的线圈数据
    rtu_data = master.execute(slave_ID,
                              cst.WRITE_MULTIPLE_COILS,
                              registers_start_addr,
                              len(coils_write),
                              output_value=coils_write)
    print(rtu_data)

    input("press any key to continue")
    master.close()
