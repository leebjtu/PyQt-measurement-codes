import pyqtgraph as pg

app = pg.mkQApp() # pyqtgraph界面APP
pg.setConfigOptions(background='w', foreground='k')  # 本地显示背景设置
# 01.LayoutWidget布局控件作为底
layout = pg.LayoutWidget()  # LayoutWidget
# 02.LayoutWidget添加RemoteGraphicsView对象
view = pg.widgets.RemoteGraphicsView.RemoteGraphicsView()
layout.addWidget(view)
layout.resize(800, 600)
layout.setWindowTitle('远程绘图最小程序Demo')
layout.show()
# 03.在RemoteGraphicsView对象中添加一个PlotWidget，并置中
rplt = view.pg.PlotItem()  # PlotWidget对象
rplt.showGrid(x=True, y=True)
view.setCentralItem(rplt)
# 04.调用代理属性和方法，就如代用本地对象一样
# line为指向远程PlotDataItem的ObjectProxy代理
line = rplt.plot(pen='r')
# 05.设置代理访问远程属性和方法模式
# line._setProxyOptions(deferGetattr=True, callSync='off')
line.setData([1,2.2,3.5,1.5,2,3])
# 06.进入主线程循环
pg.exec()