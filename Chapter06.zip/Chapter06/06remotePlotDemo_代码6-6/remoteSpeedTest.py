"""
This example demonstrates the use of RemoteGraphicsView to improve performance in
applications with heavy load. It works by starting a second process to handle
all graphics rendering, thus freeing up the main process to do its work.

In this example, the update() function is very expensive and is called frequently.
After update() generates a new set of data, it can either plot directly to a local
plot (bottom) or remotely via a RemoteGraphicsView (top), allowing speed comparison
between the two cases. IF you have a multi-core CPU, it should be obvious that the
remote case is much faster.
"""

from time import perf_counter
from pyqtgraph import  mkPen
import numpy as np

import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtWidgets

app = pg.mkQApp()

view = pg.widgets.RemoteGraphicsView.RemoteGraphicsView()
pg.setConfigOptions(antialias=True)  ## this will be expensive for the local plot
view.pg.setConfigOptions(antialias=True)  ## prettier plots at no cost to the main process!
view.setWindowTitle('pyqtgraph example: RemoteSpeedTest')

app.aboutToQuit.connect(view.close)

label = QtWidgets.QLabel()
rcheck = QtWidgets.QCheckBox('plot remote')
rcheck.setChecked(True)
lcheck = QtWidgets.QCheckBox('plot local')
lplt = pg.PlotWidget()
layout = pg.LayoutWidget()
layout.addWidget(rcheck)
layout.addWidget(lcheck)
layout.addWidget(label)
layout.addWidget(view, row=1, col=0, colspan=3)
layout.addWidget(lplt, row=2, col=0, colspan=3)
layout.resize(800, 800)
layout.show()

## Create a PlotItem in the remote process that will be displayed locally
rplt = view.pg.PlotItem()
# rplt._setProxyOptions(deferGetattr=True)  ## speeds up access to rplt.plot
view.setCentralItem(rplt)

lastUpdate = perf_counter()
avgFps = 0.0


line1 = rplt.plot(clear=True, pen='r')  ## We do not expect a return value.
line1._setProxyOptions(deferGetattr=True, callSync='off')  ## speeds up access to rplt.plot

line2 = rplt.plot(pen='y')  ## We do not expect a return value.
line2._setProxyOptions(deferGetattr=True, callSync='off')  ## speeds up access to rplt.plot



line3 = rplt.plot(pen='w')  ## We do not expect a return value.
line3._setProxyOptions(deferGetattr=True, callSync='off')  ## speeds up access to rplt.plot
# line3._setProxyOptions(callSync='off')


def update():
    global check, label, plt, lastUpdate, avgFps, rpltfunc, line, data


    data = np.random.normal(size=(10000, 50)).sum(axis=1)
    data += 10 * np.sin(np.linspace(0, 10, data.shape[0]))
    x1 = np.linspace(0, 10, data.shape[0])
    if rcheck.isChecked():
        line1.setData(x1, data)
        # rplt.plot(x1, data,clear=True, pen='r'_callSync='off')  ## We do not expect a return value.
        line2.setData(x1+10, data)
        line3.setData(x1+20, data)
        ## By turning off callSync, we tell
        ## the proxy that it does not need to
        ## wait for a reply from the remote
        ## process.
    if lcheck.isChecked():
        lplt.plot(data, clear=True)

    now = perf_counter()
    fps = 1.0 / (now - lastUpdate)
    lastUpdate = now
    avgFps = avgFps * 0.8 + fps * 0.2
    label.setText("Generating %0.2f fps" % avgFps)


timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(0)

if __name__ == '__main__':
    pg.exec()
