# myMatplot.py
from PyQt6.QtWidgets import QWidget, QVBoxLayout
from pyqtgraph import GraphicsLayoutWidget, mkPen
import pyqtgraph as pg
class myQMatplot(QWidget):
    def __init__(self, parent =None, width=8, height=5):
        super().__init__(parent)
        # 01.全局设置
        pg.setConfigOptions(background='w', foreground='k')
        # 02.在画布上绘制GraphicsLayoutWidget对象
        self.layoutWidget = GraphicsLayoutWidget(self) # 布局容器，方便后续添加PlotItem对象
        self.plt = self.layoutWidget.addPlot(row=0, col=0)  # 返回PlotItem对象，子图类似matplot中的add_subplot(111)
        # self.plt2 = self.layoutWidget.addPlot(row=1, col=0)
        # 03.设置子图轴标签信息
        self.initAxes()
        # 04.布局
        self.initLayout()
        # 05.通道数据
        self.channels = []  # 存放所有的通道数据
    # 初始化子图标签信息
    def initAxes(self):
        self.plt.showGrid(x=True, y=True)
        self.plt.enableAutoRange('y', 0.95)  # Y轴自动范围：95%数据显示
        self.plt.setLabels(left=u"电压/V",bottom=u"时间/s",title=u"电压时间波形图")
    # 布局
    def initLayout(self):
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.layoutWidget)
    # 增加通道
    def addChannel(self, legend='legend', symbol=None, *args, **kargs):
        channel = myChannel(self.plt, legend, symbol, *args, **kargs)  # 表示创建一条黄色的曲线
        self.channels.append(channel)
    # 获取当前通道
    def getChannel(self, index):
        return self.channels[index]

#*************环形缓冲区初始化**************
class myChannel():
    """
    plt:PlotItem对象
    legend:图例字符串
    symbol:'o', 's', 't', 't1', 't2', 't3', 'd', '+', 'x', 'p', 'h', 'star', 'arrow_up', 'arrow_right', 'arrow_down', 'arrow_left', 'crosshair'
    args, kargs：mkPen的初始化参数，如：width=1, color='r', dash=[10,5]
    """
    def __init__(self, plt, legend, symbol, *args, **kargs):
        pen = mkPen(*args, **kargs)  # mkPen是构造QPen的便利函数类
        self.curve = plt.plot(pen=pen,symbol= symbol)   # 返回PlotDataItem对象
        plt.addLegend().addItem(self.curve, legend) # 添加图例
    # 向通道添加数据，入口数据类型为np.ndarray或list
    def addXYArrays(self, XdataArray, YdataArray):
        self.curve.setData(XdataArray, YdataArray)

if __name__ == "__main__":
    from PyQt6 import QtWidgets
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = myQMatplot()
    MainWindow.show()
    MainWindow.addChannel(legend='channel0', width=2, color='k')
    MainWindow.getChannel(0).addXYArrays([0,1,2,3,4,5],[1.2,2.2,3.5,2.5,1,1.5])

    sys.exit(app.exec())




