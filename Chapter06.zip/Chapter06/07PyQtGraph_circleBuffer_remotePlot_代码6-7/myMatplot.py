# myMatplot.py 增加多进程绘图
from PyQt6.QtWidgets import QWidget, QVBoxLayout
import pyqtgraph as pg
import numpy as np
from pyqtgraph import multiprocess as mp


class myQMatplot(QWidget):
    def __init__(self, parent=None, width=8, height=5):
        super().__init__(parent)
        pg.setConfigOptions(background='w', foreground='r')
        # 01.创建RemoteGraphicsView对象
        self.view = pg.widgets.RemoteGraphicsView.RemoteGraphicsView()
        # 02.在画布上绘制GraphicsLayoutWidget对象
        self.layoutWidget = pg.LayoutWidget(self)  # 布局容器，方便后续添加PlotItem对象
        # 03.全局设置
        self.view.pg.setConfigOptions(background='k', foreground='b')
        self.layoutWidget.addWidget(self.view, row=1, col=0, colspan=3)  # 返回PlotItem对象，子图类似matplot中的add_subplot(111)
        self.plt = self.view.pg.PlotItem()  # PlotItem对象代理
        self.plt._setProxyOptions(deferGetattr=True)  # speeds up access to rplt.plot
        self.view.setCentralItem(self.plt)
        # self.plt = self.layoutWidget.addPlot(row=0, col=0)  # 返回PlotItem对象，子图类似matplot中的add_subplot(111)
        # self.plt2 = self.layoutWidget.addPlot(row=1, col=0)
        # 03.关联左下角A按钮和手动拖拽绘图动作，决定X轴是否实时更新
        self.plt.vb.sigRangeChangedManually.connect(mp.proxy(self.do_rangeChangedManually_changed))  # 当手动拖拽绘图时触发
        self.plt.autoBtn.clicked.disconnect()  # 取消左下角的A按钮信号槽默认信号槽
        self.plt.autoBtn.clicked.connect(mp.proxy(self.do_autoBtn_clicked, autoProxy=True))  # autoProxy=True
        # 04.设置子图轴标签信息
        self.initAxes()
        # 05.布局
        self.initLayout()
        # 06.通道数据
        self.channels = []  # 存放所有的通道数据

    # 初始化子图标签信息
    def initAxes(self):
        # self.plt.setDownsampling(auto=True)  # 数据量大时下采样优化
        self.plt.showGrid(x=True, y=True)
        self.plt.enableAutoRange('y', 0.95)  # Y轴自动范围：95%数据显示
        self.plt.setLabels(left=u"电压/V", bottom=u"时间/s", title=u"电压时间波形图(多进程)")

    # 布局
    def initLayout(self):
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.layoutWidget)

    # 增加通道
    def addChannel(self, legend='legend', symbol=None, *args, **kargs):
        channel = myChannel(self.plt, legend, symbol, *args, **kargs)  # 新建通道
        self.channels.append(channel)

    # 获取当前通道
    def getChannel(self, index):
        return self.channels[index]

    # 槽函数：手动拖动绘图时执行X轴标签不更新
    # obj:鼠标XY是否移动的布尔值元组
    def do_rangeChangedManually_changed(self, obj):
        if myChannel.updateXlim:
            myChannel.updateXlim = False
            print("停止滚动!")

    # 槽函数：点击左下角A按钮时执行X轴标签更新
    # obj：被点击的ButtonItem对象
    def do_autoBtn_clicked(self, obj):
        if not myChannel.updateXlim:
            myChannel.updateXlim = True
            print("继续滚动!")


# *************环形缓冲区初始化**************
class myChannel():
    updateXlim = True  # 决定X轴标签是否实时更新
    """
    plt:PlotItem对象
    legend:图例字符串
    symbol:'o', 's', 't', 't1', 't2', 't3', 'd', '+', 'x', 'p', 'h', 'star', 'arrow_up', 'arrow_right', 'arrow_down', 'arrow_left', 'crosshair'
    args, kargs：mkPen的画笔初始化参数，如：width=1, color='r', dash=[10,5]
    """

    def __init__(self, plt, legend, symbol, *args, **kargs):
        self.__plt = plt
        self.__max_chunks = 10  # 缓冲区的个数
        self.__lines = []  # 存放缓冲区PlotDataItem对象的列表
        self.__buffer_index = 0  # 缓冲区指针
        self.__last_data_x = None  # 初值，表示不绘图
        self.__last_data_y = None
        self.__x_span = 2  # 默认X轴的宽度为5s
        self.__x_span_offset = 0  # 默认X轴的右边空个几秒
        # 用来绘制线条的画笔
        # pen = mkPen(*args, **kargs)  # mkPen是构造QPen的便利函数类
        self.initCircleBuffer(legend, symbol, *args, **kargs)

    # 初始化环形缓冲区，把通道的图例等属性赋值给第0个line
    def initCircleBuffer(self, legend, symbol, *args, **kargs):
        for index in range(0, self.__max_chunks):
            # params = {'symbol': symbol}
            line = self.__plt.plot(symbol=symbol)  # 返回PlotDataItem对象的代理
            line._setProxyOptions(deferGetattr=True, callSync='off')  # 加速访问line
            line.setPen(*args, **kargs)
            if index == 0:  # 只有第一个加上图例
                self.__plt.addLegend().addItem(line, legend)  # 添加图例
            self.__lines.append(line)  # 增加max_chunks个curve给curves

    # 向通道添加数据，入口数据类型为np.ndarray
    def addXYArrays(self, XdataArray, YdataArray):
        # 01如果到最后一个缓冲区，则从第0个重新开始
        if self.__buffer_index >= len(self.__lines):
            self.__buffer_index = 0
        # 02每个line之间头尾数据连不上线，故后来的line头数据多画一个点（前一个line尾点）
        x_array = np.insert(XdataArray, 0, self.__last_data_x)
        y_array = np.insert(YdataArray, 0, self.__last_data_y)
        self.__last_data_x = x_array[-1]
        self.__last_data_y = y_array[-1]
        # 03赋值最新数据给当前缓冲区
        self.__lines[self.__buffer_index].setData(x_array, y_array)
        # 04设置x轴的标签范围
        if myChannel.updateXlim:
            self.__plt.setXRange(x_array[-1] - self.__x_span + self.__x_span_offset,
                                 x_array[-1] + self.__x_span_offset, _callSync='off')
            self.__plt.enableAutoRange('y', 0.95, _callSync='off')  # Y轴自动范围：95%数据显示
        self.__buffer_index += 1


if __name__ == "__main__":
    from PyQt6 import QtWidgets
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = myQMatplot()
    MainWindow.show()
    MainWindow.addChannel(legend='channel0', width=2, color='k')
    MainWindow.getChannel(0).addXYArrays([0, 1, 2, 3, 4, 5], [1.2, 2.2, 3.5, 2.5, 1, 1.5])

    sys.exit(app.exec())
