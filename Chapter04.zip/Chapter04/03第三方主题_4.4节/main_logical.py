from main_ui import Ui_mainForm
from PyQt6.QtWidgets import QWidget, QApplication
class QmyWidget(QWidget):
    def __init__(self, parent = None):
        super().__init__(parent)
        self.ui = Ui_mainForm()
        self.ui.setupUi(self)

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    mainForm = QmyWidget()
    mainForm.show()
    # 01.第三方库qt_material主题示例
    from qt_material import apply_stylesheet
    apply_stylesheet(app, theme='dark_teal.xml')
    # 02.可选择性地将qt_material导出主题
    """  
    from qt_material import export_theme
    export_theme(theme='dark_teal.xml',
                 qss='dark_teal.qss',
                 rcc='resources.rcc',
                 output='theme',
                 prefix='icon:/',
                 invert_secondary=False,
                 )
    """
    # 03.第三方库qdarkgraystyle主题
    """
    import qdarkgraystyle
    from QSSLoader import QSSTool
    app.setStyleSheet(qdarkgraystyle.load_stylesheet())
    """
    sys.exit(app.exec())