from client_ui import Ui_tcpClient
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QMessageBox
from PyQt6.QtCore import pyqtSlot
from modbus_tk import modbus_tcp
from modbus_tk import hooks
import modbus_tk.defines as cst
import time
from PyQt6.QtGui import QTextCursor

class client_logical(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.client_ui = Ui_tcpClient()
        self.client_ui.setupUi(self)
        hooks.install_hook("modbus_tcp.TcpMaster.before_send", self.before_send) # 一旦客户端连接，执行自定函数client_on_connect()
        hooks.install_hook("modbus_tcp.TcpMaster.after_recv", self.after_recv) # 一旦客户端连接，执行自定函数client_on_connect()



    # ===========向日志框里填入含时间标签的内容=======
    def showMessage(self,str):
        self.client_ui.txtLog.moveCursor(QTextCursor.End)
        strText = time.strftime("[%Y-%m-%d %H:%M:%S]: ", time.localtime()) + str
        self.client_ui.txtLog.append(strText)

    # ===========发送请求之前执行如下钩子函数=======
    def before_send(self,tuple):
        # tuple = (master, request)
        request = tuple[1]
        strSend = ''
        for byte in request:
            strSend = strSend + "{:#04X} ".format(byte)
        self.showMessage("-" * 30)
        self.showMessage("发送请求字节序列：" + '\n' + strSend)

    # ======接收到响应数据之后执行如下钩子函数=====
    def after_recv(self,tuple):
        # tuple = (master, response)
        response = tuple[1]
        strRecv = ''
        for byte in response:
            strRecv = strRecv + "{:#04X} ".format(byte)
        self.showMessage("收到字节序列："+'\n'+strRecv)

    # =================连接按钮单击槽函数=====================
    @pyqtSlot()
    def on_btnStart_clicked(self):
        if self.client_ui.btnStart.text() == "连接服务器":
            # 获取服务器IP和port
            try:
                ipText = self.client_ui.lineEditIP.text()
                portValue = int(self.client_ui.lineEditPort.text())
                # 本地连接127.0.0.1, 只是配置信息，并没有产生连接
                self.master = modbus_tcp.TcpMaster(host=ipText,port=portValue,timeout_in_sec=1)
                self.master.open()
            except Exception as e:
                print("Modbus error", str(e))
                QMessageBox.warning(self, "错误", str(e))
            else:  # 开始监听
                self.showMessage("服务器连接成功！")
                self.client_ui.btnStart.setText("断开服务器")
        else:
            self.client_ui.btnStart.setText("连接服务器")
            self.showMessage("服务器断开连接！")
            self.master.close()

    # =========读线圈按钮槽函数=================
    @pyqtSlot()
    def on_btnReadCoils_clicked(self):
        coilsValues = self.master.execute(slave=1, function_code=cst.READ_COILS, starting_address=0, quantity_of_x=10)
        strRecv = ''
        for byte in coilsValues: # 低地址线圈值对应低索引序号元组值
            strRecv = strRecv + "{:#b} ".format(byte)
        self.showMessage("【读线圈】的结果：" + '\n' + strRecv)

    # =========写单个线圈槽函数=================
    @pyqtSlot()
    def on_btnWriteSingleCoil_clicked(self):
        coilsRes = self.master.execute(slave=1, function_code=cst.WRITE_SINGLE_COIL, starting_address=1, output_value=1)
        strRecv = ''
        for byte in coilsRes: # [0]为写入的地址，[1]为写入的值，均为2个字节
            strRecv = strRecv + "{:#b} ".format(byte)
        self.showMessage("【写单个线圈】的结果：" + '\n' + strRecv)

    # =========写多个线圈按钮槽函数================
    @pyqtSlot()
    def on_btnWriteMultiCoils_clicked(self):
        # [0,0,0,1]低索引序号值在对应低地址线圈的值，即0x8
        coilsRes = self.master.execute(slave=1, function_code=cst.WRITE_MULTIPLE_COILS, starting_address=0, output_value=[0,0,0,1])
        strRecv = ''
        for byte in coilsRes: # [0]为写入的地址，[1]为写入的数量，均为2个字节
            strRecv = strRecv + "{:#X} ".format(byte)
        self.showMessage("【写单个线圈】的结果：" + '\n' + strRecv)

    # =========读保持寄存器按钮槽函数=================
    @pyqtSlot()
    def on_btnReadMultiRegisters_clicked(self):
        registerValues = self.master.execute(slave=1, function_code=cst.READ_HOLDING_REGISTERS, starting_address=0, quantity_of_x=6, data_format="fff")
        # import struct
        # numberOfFloats = 3
        # registerValues = self.master.execute(slave=1, function_code=cst.READ_HOLDING_REGISTERS, starting_address=0,
        #                                      quantity_of_x= int(numberOfFloats * struct.calcsize("f") / 2),
        #                                      data_format="f" * numberOfFloats)
        #
        # print(registerValues)
        strRecv = ''
        for byte in registerValues: # 低地址寄存器值对应低索引序号元组值
            strRecv = strRecv + "{:#06X} ".format(byte)
        self.showMessage("【读保持寄存器】的结果：" + '\n' + strRecv)

    # =========写单个寄存器按钮槽函数=================
    @pyqtSlot()
    def on_btnWriteSingleRegister_clicked(self):
        res = self.master.execute(slave=1, function_code=cst.WRITE_SINGLE_REGISTER, starting_address=0, output_value=0xFF01)
        strRecv = ''
        for byte in res:  # [0]为写入的地址，[1]为写入的值
            strRecv = strRecv + "{:#06X} ".format(byte)
        self.showMessage("【写单个保持寄存器】的结果：" + '\n' + strRecv)

    # =========写多个保持寄存器按钮槽函数=================
    @pyqtSlot()
    def on_btnWriteMultiRegisters_clicked(self):
        # floats = [1.1,2.1,3.1]
        # res = self.master.execute(slave=1, function_code=cst.WRITE_MULTIPLE_REGISTERS, starting_address=0, output_value = floats, data_format="f"*len(floats))

        res = self.master.execute(slave=1, function_code=cst.WRITE_MULTIPLE_REGISTERS, starting_address=0, output_value=[0x0001,0x0002,0x0003,0x0004])
        strRecv = ''
        for byte in res:  # [0]为写入的地址，[1]为写入的数量
            strRecv = strRecv + "{:#06X} ".format(byte)
        self.showMessage("【写多个保持寄存器】的结果：" + '\n' + strRecv)



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = client_logical()
    ui.show()
    sys.exit(app.exec())
