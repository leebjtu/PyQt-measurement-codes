from server_ui import Ui_tcpServer
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QMessageBox
from PyQt6.QtCore import pyqtSlot, pyqtSignal
import socket
import threading
import time

class server_logical(QWidget):
    pyqtSignal_data_get = pyqtSignal(str) #收到数据信号
    def __init__(self, parent = None):
        super().__init__(parent)
        self.server_ui = Ui_tcpServer()
        self.server_ui.setupUi(self)
        self.list_connections=[] # 用来记录socket产生了多少个connectionSocket和addr
# =======================向日志里填入含时间标签的内容================
    def showMessage(self,str):
        self.server_ui.plainTextEditDebug.insertPlainText(time.strftime("[%Y-%m-%d %H:%M:%S]: ", time.localtime()) + str+'\n')

# ================把当前有效的connectionSocket信息更新至QWidgetList显示=======================
    def updateIPList(self):
        self.server_ui.listWidget.clear()
        for clientSocket, addr in self.list_connections:
            self.server_ui.listWidget.addItem(addr[0]+":"+str(addr[1]))
# =================开始按钮单击槽函数=====================
    @pyqtSlot()
    def on_btnStart_clicked(self):
        # 改变btn状态
        if self.server_ui.btnStart.text() == "开启服务器":
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 基于文件，实现同一主机不同进程之间的通信, TCPIP
            # 获取服务器IP和port
            try:
                ipText = self.server_ui.lineEditIP.text()
                portValue = int(self.server_ui.lineEditPort.text())
                self.socket.bind((ipText, portValue))  # 套接字绑定
            except Exception as e:
                warningStr = "绑定端口错误：" + str(e)
                QMessageBox.warning(self, "错误", warningStr)
            else:  # 开始监听
                self.showMessage("监听中...")
                self.socket.listen(20)  # 开始监听 表示可以使用五个链接排队
                # 创建一个进程，用于处理socket连接和接收数据
                self.listenFromClient_th = threading.Thread(target=self.connectFromClient)
                self.listenFromClient_th.setDaemon(True)
                self.listenFromClient_th.start()
                self.server_ui.btnStart.setText("停止服务器")
        else:
            self.server_ui.btnStart.setText("开启服务器")
            self.showMessage("监听停止")
            for (clientsocket,addr) in self.list_connections:
                clientsocket.close()
            self.list_connections.clear()
            self.socket.close()

# =========单击发送消息按钮=================
    @pyqtSlot()
    def on_btnSendMsg_clicked(self):
        selectedItems =self.server_ui.listWidget.selectedItems()
        for item in selectedItems:
            for clientSocket,addr in self.list_connections:
                if item.text() == (addr[0]+":"+str(addr[1])):
                    msgSend = self.server_ui.textSendMsg.toPlainText()
                    clientSocket.send(msgSend.encode('utf-8'))

# =================连接监听线程=====================
    def connectFromClient(self):
        while True:
            try:
                clientSocket, addr = self.socket.accept() # 阻塞建立来自客户端的连接，一旦连接就创建一个线程专门接受数据
                self.list_connections.append((clientSocket,addr)) # clientSocket用来发数据用的，记录list总表
                self.updateIPList()
                # 每接受来自一个新客户端的链接，就产生一组connection和addr对象，然后就产生一个新线程
            except Exception as e:
                # 一旦self.socket.close（）被调用，则上述发生异常，此线程完毕，该场景发生在主动停止tcp服务
                break # 终止线程
            else:
                self.showMessage("连接来自 :" + addr[0] + ":" + str(addr[1]))
                # 产生新线程，用来传递数据
                linked_thread = threading.Thread(target= self.clientLlinked, args=(clientSocket, addr))
                linked_thread.setDaemon(True)
                linked_thread.start()

# ===============接收监听线程=======================
# 会话生成以后，等来来自客户端的消息线程
    def clientLlinked(self, connectionSocket, clientAddr):
        bufferSize =1024
        while True:
            if connectionSocket is not None: # 如果connection还在链接
                data = connectionSocket.recv(bufferSize) # 阻塞，等待客户端发送数据
                if not data:  # 如果客户端已经关闭了连接
                    if (connectionSocket, clientAddr) in self.list_connections:
                        self.list_connections.remove((connectionSocket, clientAddr)) # 从总的注册链接中去掉当前链接
                        self.updateIPList()
                        connectionSocket.close()  # 关闭了正在占线的连接
                        self.showMessage("连接关闭 :" + clientAddr[0] + ":" + str(clientAddr[1]))
                        break
                else: # 打印来自客户端的消息
                    self.showMessage("消息来自 :" + clientAddr[0] + ":" + str(clientAddr[1])+ "\n"+data.decode('utf-8') )
                    self.pyqtSignal_data_get.emit(data.decode('utf-8'))
            else: # connectionSocket.close() 被调用，就退出线程,发生在客户端主动关闭连接
                break





if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = server_logical()
    ui.show()
    sys.exit(app.exec())







