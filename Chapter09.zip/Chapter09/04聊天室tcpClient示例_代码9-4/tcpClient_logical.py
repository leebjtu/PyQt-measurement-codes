from client_ui import Ui_tcpClient
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QMessageBox
from PyQt6.QtCore import pyqtSlot
import socket
import threading
import time

class client_logical(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.client_ui = Ui_tcpClient()
        self.client_ui.setupUi(self)

    # ===========向日志里填入含时间标签的内容=======
    def showMessage(self,str):
        self.client_ui.plainTextEditDebug.insertPlainText(time.strftime("[%Y-%m-%d %H:%M:%S]: ", time.localtime()) + str+'\n')

    # =========单击发送消息按钮=================
    @pyqtSlot()
    def on_btnSendMsg_clicked(self):
        try:
            msgSend = self.client_ui.textSendMsg.toPlainText()
            self.socket.send(msgSend.encode('utf-8'))
        except Exception as e:
            warningStr = "请先连接至服务器"
            QMessageBox.warning(self, "错误", warningStr)
        else:
            self.showMessage("发送消息至服务器成功：\n"+msgSend)

    # =================开始按钮单击槽函数=====================
    @pyqtSlot()
    def on_btnStart_clicked(self):
        # 改变btn状态
        if self.client_ui.btnStart.text() == "连接服务器":
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 基于文件，实现同一主机不同进程之间的通信, TCPIP
            # 获取服务器IP和port
            try:
                ipText = self.client_ui.lineEditIP.text()
                portValue = int(self.client_ui.lineEditPort.text())
                self.socket.connect((ipText, portValue))  # 套接字绑定
            except Exception as e:
                warningStr = "连接至服务器错误：" + str(e)
                QMessageBox.warning(self, "错误", warningStr)
            else:  # 开始监听
                self.showMessage("服务器连接成功！")
                # 创建一个进程，用于处理socket连接和接收数据
                self.recvFromServer_th = threading.Thread(target=self.recvFromClient)
                self.recvFromServer_th.setDaemon(True)
                self.recvFromServer_th.start()
                self.client_ui.btnStart.setText("断开服务器")
        else:
            self.client_ui.btnStart.setText("连接服务器")
            self.socket.close()

    # =================客户端接受监听线程=====================
    def recvFromClient(self):
        bufferSize = 1024
        while True:
            try:
                data = self.socket.recv(bufferSize)  # 阻塞，等服务端端发送数据
                if not data:  # 如果服务端主动关闭了连接
                    self.socket.close()  # 关闭了正在占线的连接
                    self.showMessage("服务器端主动断开了连接")
                    self.client_ui.btnStart.setText("连接服务器")
                    break
                else:  # 打印来自客户端的消息
                    self.showMessage("来自服务器的消息 :" "\n" + data.decode('utf-8'))
            except Exception as e: # 如果客户端主动关闭，发生在self.socket.close()被调用
                self.showMessage("已经从服务器断开连接")
                break


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = client_logical()
    ui.show()
    sys.exit(app.exec())
