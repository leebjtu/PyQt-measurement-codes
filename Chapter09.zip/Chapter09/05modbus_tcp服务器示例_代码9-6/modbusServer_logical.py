from server_ui import Ui_modbusTcpServer
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QWidget, QTableWidgetItem
from PyQt6.QtCore import pyqtSlot, Qt
from PyQt6.QtGui import QTextCursor
import time
import math
from modbus_tk import modbus_tcp
from modbus_tk import hooks
import modbus_tk.defines as cst

class server_logical(QWidget):
    def __init__(self, parent = None):
        super().__init__(parent)
        self.server_ui = Ui_modbusTcpServer()
        self.server_ui.setupUi(self)
        self.clients=[] # 客户端连接列表，放置(ip,port)元组
        # modbus_tk做了一些钩子函数，供用户调用
        hooks.install_hook("modbus_tcp.TcpServer.on_connect", self.client_on_connect) # 一旦客户端连接，执行自定函数client_on_connect()
        hooks.install_hook("modbus_tcp.TcpServer.on_disconnect", self.client_on_disconnect) # 一旦客户端断开连接，执行自定函数client_on_disconnect()
        hooks.install_hook("modbus.Server.before_handle_request",self.before_handle_request)
        hooks.install_hook("modbus.Server.after_handle_request",self.after_handle_request)

    # 给 设备中添加线圈和保持寄存器的内存块，并赋予初值
    def initData(self):
        self.slave = self.SERVER.add_slave(slave_id=1)  # 这个id就是MBAP的 slave id,类似添加一个服务端设备
        self.slave.add_block("coils", cst.COILS, 0, 32)  # 在设备上开辟的coils地址和值序列块，给序列取个名字
        self.slave.set_values("coils", 0, [1, 1, 1, 0, 0, 0, 1, 1]) # 给线圈序列一些初始状态
        self.slave.add_block("holdingRegisters",cst.HOLDING_REGISTERS,0,32)
        self.slave.set_values("holdingRegisters", 0, [0x01, 0x02]) # 给保持寄存器序列一些初始数据

        self.updateTables()  # 更新这些初始数据到表格

    def updateTables(self):
        self.server_ui.tbCoils.setColumnCount(8)
        self.server_ui.tbCoils.setRowCount(math.ceil(32 / 8))  # 设置行，行数为属性个数
        self.server_ui.tbRegisters.setColumnCount(8)
        self.server_ui.tbRegisters.setRowCount(math.ceil(32 / 8))  # 设置行，行数为属性个数

        self.server_ui.tbCoils.setHorizontalHeaderLabels(
            ["0x01", "0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07"])
        self.server_ui.tbCoils.setVerticalHeaderLabels(["0x10", "0x20", "0x30", "0x40"])

        self.server_ui.tbRegisters.setHorizontalHeaderLabels(
            ["0x01", "0x01", "0x02", "0x03", "0x04", "0x05", "0x06", "0x07"])
        self.server_ui.tbRegisters.setVerticalHeaderLabels(["0x10", "0x20", "0x30", "0x40"])

        if self.slave is not None:
            coils = self.slave.get_values("coils", 0, 32)
            holdingRegisters = self.slave.get_values("holdingRegisters", 0, 32)
            addr = 0
            for value in coils:
                keynewItem = QTableWidgetItem(str(value))
                keynewItem.setTextAlignment(Qt.AlignVCenter | Qt.AlignHCenter)
                keynewItem.setFlags(Qt.ItemIsEditable | Qt.ItemIsSelectable)
                self.server_ui.tbCoils.setItem(addr//8, addr%8, keynewItem)
                addr +=1
            self.server_ui.tbCoils.viewport().update()

            addr = 0
            for value in holdingRegisters :
                keynewItem = QTableWidgetItem("{:#06X}".format(value))
                keynewItem.setTextAlignment(Qt.AlignVCenter | Qt.AlignHCenter)
                keynewItem.setFlags(Qt.ItemIsEditable | Qt.ItemIsSelectable)
                self.server_ui.tbRegisters.setItem(addr//8, addr%8, keynewItem)
                addr += 1
            self.server_ui.tbRegisters.viewport().update()



# =======================向日志里填入含时间标签的内容================
    def showMessage(self,str):
        self.server_ui.txtLog.moveCursor(QTextCursor.End)
        strText = time.strftime("[%Y-%m-%d %H:%M:%S]: ", time.localtime()) + str
        # print(strText)
        self.server_ui.txtLog.append(strText)


# ================把当前有效的connectionSocket信息更新至QWidgetList显示=======================
    def updateIPList(self):
        self.server_ui.listWidget.clear()
        for (ip, port) in self.clients:
            self.server_ui.listWidget.addItem(ip+':'+str(port))

# =================开始按钮单击槽函数=====================
    @pyqtSlot()
    def on_btnStart_clicked(self):
        # 改变btn状态
        if self.server_ui.btnStart.text() == "开启服务器":
            try:
                ipText = self.server_ui.lineEditIP.text()
                portValue = int(self.server_ui.lineEditPort.text())
                self.SERVER = modbus_tcp.TcpServer(address=ipText, port=portValue)
                self.initData()
                self.SERVER.start() # 非阻塞
            except Exception as e:
                self.showMessage("开启modbus出错"+str(e))
            else:
                self.showMessage("modbus服务器已开启")
                self.server_ui.btnStart.setText("关闭服务器")
        else:
            self.server_ui.btnStart.setText("开启服务器")
            self.SERVER.stop()
            self.showMessage("modbus服务器已关闭")
            self.clients.clear()
            self.updateIPList()


    def client_on_connect(self, tuple):
        # tuple =(TcpServer, clientSocket, address)
        address = tuple[2]
        self.clients.append((address[0],address[1]))
        self.updateIPList()
        self.showMessage("已连接:"+address[0]+':'+str(address[1]))

    def client_on_disconnect(self, tuple):
        # tuple=(server, sock)
        sock = tuple[1]
        ip, port = sock.getpeername()
        self.clients.remove((ip, port))
        self.updateIPList()
        self.showMessage("已断开:"+ip+':'+str(port))

    def before_handle_request(self,tuple):
        # tuple =(server, request)
        server = tuple[0]
        request = tuple[1]
        strRecv = ''
        for byte in request:
            strRecv = strRecv + "{:#04X} ".format(byte)
        self.showMessage("收到字节序列："+'\n'+strRecv)

    def after_handle_request(self,tuple):
        # tuple =(server, response)
        server = tuple[0]
        response = tuple[1]
        if len(response) !=0:
            strResponse = ''
            for byte in response:
                strResponse = strResponse + "{:#04X} ".format(byte)

            self.showMessage("已回复字节序列：" + '\n' + strResponse)
            self.updateTables()

    def on_error(self,tuple):
        # tuple =(server, sock, excpt)
        print("on_error"+str(tuple[2]))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = server_logical()
    ui.show()
    sys.exit(app.exec())







